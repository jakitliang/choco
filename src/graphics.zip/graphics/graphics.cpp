//
// Created by jakit on 2023/11/20.
//

#include "choco/graphics/graphics.h"
#include <stack>
#include <SDL.h>
#include <iostream>

static Choco::Graphics graphics;

struct Choco::GraphicsImpl {
    std::stack<GraphicsState> state;

    void initialize() {
        state = std::stack<GraphicsState>();
        state.push(GraphicsState());
    }
};

Choco::Graphics & Choco::Graphics::Instance() {
    return graphics;
}

void Choco::Graphics::push() {
    impl_->state.push(GraphicsState());
}

void Choco::Graphics::pop() {
    impl_->state.pop();
}

Choco::GraphicsState & Choco::Graphics::state() {
    return impl_->state.top();
}

Choco::GraphicsColor & Choco::Graphics::getColor() {
    return impl_->state.top().color;
}

void Choco::Graphics::setColor(Byte r, Byte g, Byte b, Byte a) {
    auto & color = impl_->state.top().color;
    color.r = r;
    color.g = g;
    color.b = b;
    color.a = a;
}

Choco::Graphics::Graphics() {
    impl_->initialize();
}
