//
// Created by jakit on 2023/11/20.
//

#include "choco/graphics/render.h"
#include <SDL.h>
#include <SDL_opengl.h>
#include <iostream>

struct Choco::RenderImpl {
    SDL_Renderer *renderer;
    SDL_Window *window;
};

Choco::Render::Render() {
    std::cout << "start init" << std::endl;
    auto & render = *this->impl_;

    if (SDL_Init(SDL_INIT_EVERYTHING) < 0)
    {
        std::cout << "Error: Init failed" << std::endl;
        exit(1);
    }

    if (SDL_SetVideo)
}

Choco::Render::~Render() {
    SDL_Quit();
}

bool Choco::Render::open(const char * title, Choco::Size width, Choco::Size height) {
    int rendererFlags = SDL_RENDERER_ACCELERATED, windowFlags = 0;
    auto & render = *this->impl_;
    render.window = SDL_CreateWindow(
            title,
            SDL_WINDOWPOS_UNDEFINED,
            SDL_WINDOWPOS_UNDEFINED,
            width,
            height,
            windowFlags);

    if (!render.window)
    {
        std::cout << "Failed to open window: "
                  << width
                  << ", "
                  << height
                  << "\n"
                  << SDL_GetError()
                  << std::endl;
        return false;
    }

//    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "linear");

    render.renderer = SDL_CreateRenderer(render.window, -1, rendererFlags);

    if (!render.renderer)
    {
        printf("Failed to create renderer: %s\n", SDL_GetError());
        exit(1);
    }

    return true;
}
